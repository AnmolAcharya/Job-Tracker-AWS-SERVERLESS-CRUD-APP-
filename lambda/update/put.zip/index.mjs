import { DynamoDBDocumentClient, UpdateCommand } from "@aws-sdk/lib-dynamodb";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";

const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);

const tableName = process.env.tableName || "JobTrackerTable";

const createResponse = (statusCode, body) => ({
    statusCode,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
});

export const updateJob = async (event) => {
    const { pathParameters, body } = event;
    const jobId = pathParameters?.id;

    if (!jobId)
        return createResponse(400, { error: "Missing jobId" });

    const { name, appliedDate, status, referall } = JSON.parse(body || "{}");

    if (!name && !appliedDate && !status && !referall)
        return createResponse(400, { error: "Nothing to update!" });

    let updateParts = [];
    let ExpressionAttributeValues = {};
    let ExpressionAttributeNames = {};

    if (name) {
        updateParts.push("#name = :name");
        ExpressionAttributeValues[":name"] = name;
        ExpressionAttributeNames["#name"] = "name"; // reserved word
    }

    if (appliedDate) {
        updateParts.push("appliedDate = :appliedDate");
        ExpressionAttributeValues[":appliedDate"] = appliedDate;
    }

    if (status) {
        updateParts.push("status = :status");
        ExpressionAttributeValues[":status"] = status;
        ExpressionAttributeNames["#status"] = "status";
    }

    if (referall) {
        updateParts.push("referall = :referall");
        ExpressionAttributeValues[":referall"] = referall;
    }

    const updateExpression = "SET " + updateParts.join(", ");

    try {
        const command = new UpdateCommand({
            TableName: tableName,
            Key: { jobId },
            UpdateExpression: updateExpression,
            ExpressionAttributeValues,
            ...(Object.keys(ExpressionAttributeNames).length > 0 && { ExpressionAttributeNames }),
            ReturnValues: "ALL_NEW",
            ConditionExpression: "attribute_exists(jobId)",
        });

        const response = await docClient.send(command);
        return createResponse(200, {
            message: "Job updated successfully",
            updatedItem: response.Attributes,
        });

    } catch (err) {
        if (err.message.includes("ConditionalCheckFailed")) {
            return createResponse(404, { error: "Item does not exist!" });
        }

        return createResponse(500, {
            error: "Internal Server Error",
            message: err.message,
        });
    }
};


// import { DynamoDBDocumentClient, UpdateCommand } from "@aws-sdk/lib-dynamodb";
// import { DynamoDBClient } from "@aws-sdk/client-dynamodb";

// const client = new DynamoDBClient({});
// const docClient = DynamoDBDocumentClient.from(client);

// const tableName = process.env.tableName || "JobTrackerTable";

// const createResponse = (statusCode, body) => {
//     const responseBody = JSON.stringify(body);
//     return {
//         statusCode,
//         headers: { "Content-Type": "application/json" },
//         body: responseBody,
//     };
// };

// export const updateJob = async (event) => {
//     const { pathParameters, body } = event;

//     const jobId = pathParameters?.id;
//     if (!jobId)
//         return createResponse(400, { error: "Missing coffeeId" });

//     const { name, appliedDate, status, referall } = JSON.parse(body || "{}");
//     if (!name && !appliedDate && !status && !referall === undefined)
//         return createResponse(400, { error: "Nothing to update!" })

//     let updateExpression = `SET  ${name ? "#name = :name, " : ""}${appliedDate ? "appliedDate = :appliedDate, " : ""}${status ? "status = :status, " : ""}${referall ? "referall = :referall, " : ""}`.slice(0, -2);

//     try {

//         const command = new UpdateCommand({
//             TableName: tableName,
//             Key: {
//                 jobId,
//             },
//             UpdateExpression: updateExpression,
//             ...(name && {
//                 ExpressionAttributeNames: {
//                     "#name": "name", // name is a reserved keyword in DynamoDB
//                 },
//             }),
//             ExpressionAttributeValues: {
//                 ...(name && { ":name": name }),
//                 ...(appliedDate&& { ":appliedDate": appliedDate }),
//                 ...(status && { ":status": status }),
//                 ...(referall && { ":status": referall })
//             },
//             ReturnValues: "ALL_NEW", // returns updated value as response
//             ConditionExpression: "attribute_exists(jobId)", // ensures the item exists before updating
//         });

//         const response = await docClient.send(command);
//         console.log(response);
//         return response;

//     }
//     catch (err) {
//         if (err.message === "The conditional request failed")
//             return createResponse(404, { error: "Item does not exists!" });
//         return createResponse(500, {
//             error: "Internal Server Error!",
//             message: err.message,
//         });
//     }
// }